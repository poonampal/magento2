<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Bundle\Test\Handler\BundleProduct;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface BundleProductInterface
 */
interface BundleProductInterface extends HandlerInterface
{
    //
}
